package belajar.java.belajarspringdasar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BelajarSpringDasarApplication {

	public static void main(String[] args) {
		SpringApplication.run(BelajarSpringDasarApplication.class, args);
	}

}
