package belajar.java.belajarspringdasar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BelajarSpringDasarApplicationTests {

	@Test
	void contextLoads() {
	}

}
